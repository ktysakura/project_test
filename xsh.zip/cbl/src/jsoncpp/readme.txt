这个jsoncpp的库是从jsoncpp-0.y.z版本移植过来的。

官方提供了一个工具，用python把源码合并成2个头文件，1个cpp文件，具体的命令是：
python amalgamate.py