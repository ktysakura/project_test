#ifndef _TIME_H_20200225_
#define _TIME_H_20200225_

long long getTimeStamp();/*millisecond*/

#endif