/* AutoLock.cpp: create automatically by makeclass at 2015-06-14 */
#include "AutoLock.h"

namespace cbl{

	
} //namespace cbl
