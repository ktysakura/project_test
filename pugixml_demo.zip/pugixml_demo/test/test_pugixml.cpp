#include "test_pugixml.h"
#include <time.h>
#include <vector>
#include <list>
#include <functional>
#include <algorithm>
#define XML_DESC(sub) const char* XML_##sub=#sub
XML_DESC(root);
XML_DESC(id);
XML_DESC(name);
XML_DESC(value);

class xml_string_writer :public pugi::xml_writer
{
public:
	string xml;

	virtual void write(const void* data, size_t size) override
	{
		xml.append((const char*)data, size);
	}
	const string & getResult()
	{
		return xml;
	}
};


const char* node_types[] =
{
	"null", "document", "element", "pcdata", "cdata", "comment", "pi", "declaration"
};

class xml_simple_walker: public xml_tree_walker
{
	virtual bool for_each(pugi::xml_node& node)
	{
		for (int i = 0; i < depth(); ++i) {
			std::cout << "	"; // indentation
		}
		std::cout << node_types[node.type()] << ": name='" << node.name() << "', value='" << node.value() << "'\n";
		return true; // continue traversal
	}
};
static int pugixml_init(xml_document &doc, const char* szPath);
static int pugixml_save_string(string &sXml);
/*prase xml*/
static int pugixml_parse_string(xml_document &xdoc, const string &sXml);
static int pugixml_test_worker(const char *szPath);
/*for earch xml*/
static int pugixml_for_each_xml(xml_document &doc);
/*for each node attribute*/
static int pugixml_for_each_attribute(xml_node &node);
/*query node*/
static int pugixml_find_node();
/*remove node*/
static int pugixml_remove_node();
/*query node by xpath*/
static int pugixml_test_xpath();
int test_pugixml_main()
{
	int ret = 0;
	xml_document xdoc;
	
	string sxml;
	//ret = pugixml_init(xdoc, "./a.xml");
	//ret = pugixml_test_worker("./a.xml");
	//ret = pugixml_save_string(sxml);
	//ret = pugixml_parse_string(xdoc, sxml);
	//ret = pugixml_for_each_xml(xdoc);
   	//ret = pugixml_find_node();
	//ret = pugixml_add_declaration(xdoc);
	ret = pugixml_remove_node();
	//ret = pugixml_insert_node(xdoc);
	//ret = pugixml_motify_attribute(xdoc);
	//ret = pugixml_test_xpath();

	return 0;
}
int pugixml_init(xml_document &doc, const char* szPath)
{
	clock_t beg_time = clock();
	xml_parse_result result = doc.load_file(szPath, pugi::parse_full, pugi::encoding_auto);
	if (result.status != status_ok){
		return -1;
	}
	printf("run time=(%d)\n", clock() - beg_time);
	//doc.save(std::cout);
	return 0;
}

int pugixml_save_string(string &sXml)
{
	std::list<PugiAttribute> listPugi;
	for (int i = 0; i < 50000; i++)
	{
		listPugi.push_back(PugiAttribute(rand() % 100, rand() % 100, "tt"));
		listPugi.push_back(PugiAttribute(rand() % 100, rand() % 100, "tt"));
		listPugi.push_back(PugiAttribute(rand() % 100, rand() % 100, "ttaaa"));
	}
	
	xml_document xdoc;
	 //����˵��
	xml_node xdec = xdoc.prepend_child(pugi::node_declaration);
	xdec.append_attribute("version").set_value("1.0");
	xdec.append_attribute("encoding").set_value("utf-8");
	xml_node xstudents = xdoc.append_child(XML_root);
	 //ע��
	xstudents.append_child(pugi::node_comment).set_value("Students!");
	for each(const PugiAttribute& pugiattri in listPugi)
	{
		//�����ӽڵ�
		xml_node xstudent = xstudents.append_child("student");
		 //���ڵ��������ԣ�����ֵ ��ʽ1
		xstudent.append_attribute(XML_id).set_value(pugiattri.id); 
		 //���ڵ��������ԣ�����ֵ ��ʽ2
		xstudent.append_attribute(XML_value) = pugiattri.value;
		xstudent.append_attribute(XML_name).set_value(pugiattri.name.c_str());
		//�����ӽڵ�
		xstudent.append_child(pugi::node_pcdata).set_value("text");
	}
	xml_string_writer writer;  
	xdoc.print(writer);
	cout << "xml ת�����ַ���:" << endl;
	sXml =  writer.getResult();
	return 0;
}	

int pugixml_test_worker(const char *szPath)
{

	xml_document xdoc;
	clock_t beg_time = clock();
	xml_parse_result result = xdoc.load_file(szPath, pugi::parse_full, pugi::encoding_utf8);
	if (result.status != status_ok){
		return -1;
	}
	printf("run time=(%d)\n", clock() - beg_time);
	xml_simple_walker walker;

	return xdoc.traverse(walker) ? 0 : -1;
}
int pugixml_parse_string(xml_document &xdoc, const string &sXml)
{
	xml_parse_result result = xdoc.load_string(sXml.c_str());
	//xdoc.load_buffer_inplace_own()
	if (result.status != status_ok){
		return -1;
	}
	return 0;
}

int pugixml_find_node()
{
	xml_document xdoc;
	xml_parse_result result;
	xml_node node;
	result = xdoc.load_file("./xpath.xml", parse_default, encoding_utf8);

	if (result.status != status_ok){
		return -1; 
	}
	node = xdoc.child("bookstore"); 
	//node = node.find_child_by_attribute("id", "2");
	node = node.find_child_by_attribute("book", "id", "2");
	node.find_child()
	for (xml_attribute xattri = node.first_attribute(); xattri; xattri = xattri.next_attribute())
	{
		cout << xattri.name() << " " << xattri.value()<<endl;
	}
	node.find_child_by_attribute("", "");
	return 0;
}	

int pugixml_remove_node()
{
	return 0;
}	


int pugixml_test_xpath()
{
	xml_document xdoc;
	xpath_query query;
	xpath_node_set xnodes;
	xml_node xnode;
	xml_parse_result result;
	
	result = xdoc.load_file("./xpath.xml", parse_default, encoding_utf8);
	if (result.status != status_ok){
		return -1;
	}

	xnodes = xdoc.select_nodes("/bookstore/book/title"); //ѡȡ���� book �����е�title
	//xnodes = xdoc.select_nodes("/bookstore/book[1]/title");//������1��ʼ,ѡȡ��һ�� book �� title
	//xnodes = xdoc.select_nodes("/bookstore/book[last()]/title");
	//xnodes = xdoc.select_nodes("/bookstore/book[last() - 1]/title");
	//xnodes = xdoc.select_nodes("/bookstore/book[position() < 3]/title");
	//xnodes = xdoc.select_nodes("/bookstore/book[position() > 2 and position() <= 5]/title");
	//xnodes = xdoc.select_nodes("/bookstore/book[position() < 2 or position() >= 4]/title");
	//xnodes = xdoc.select_nodes("/bookstore/book[price>35.00]");
	//xnodes = xdoc.select_nodes("/bookstore/book[price>35.00]/title");
	//xnodes = xdoc.select_nodes("/bookstore/book[@category='COOKING']/title");
	//xnodes = xdoc.select_nodes("//book[title='Harry Potter'] | //book[price>35.00]/price");
	//xnodes = xdoc.select_nodes("/bookstore/book/title | //price");
	//xnodes = xdoc.select_nodes("//author[@age > 3]");
	//xnodes = xdoc.select_nodes("//author[@age = 3]");
	//xnodes = xdoc.select_nodes("//author[@age = '3']");
	//xnodes = xdoc.select_nodes("//author[@age]");//ѡȡ����ӵ��age���Ե� author Ԫ�ء�
	//xnodes = xdoc.select_nodes("//author[@*]");  //ѡȡ���д������Ե� author Ԫ�ء�
	//xnodes = xdoc.select_nodes("//author");      //ѡȡ����author Ԫ�ء�
	//xnodes = xdoc.select_nodes("//book[author='Vaidyanathan Nagarajan']");
	for (pugi::xpath_node_set::const_iterator it = xnodes.begin(); it != xnodes.end(); ++it){
		xnode = it->node();
		cout <<"<"<< xnode.name() <<">"<<endl;
		for(xml_node node = xnode.first_child(); node; node = node.next_sibling()){
			cout << "<" << node.name();
			pugixml_for_each_attribute(node);
			if (node.text()){
				cout << ">" << node.text().as_string()<< "<" << node.name();
			}
			cout <<"/>";
			cout << endl;
		}
		cout << "<" <<"/" << xnode.name() << ">" << endl;
	}
	return 0;
}	

int pugixml_for_each_xml(xml_document &doc)
{
	xml_node root = doc.child(XML_root);
	
	/*����ָ�����ֵ��ӽڵ�*/
	for (xml_node node = root.child("student"); node; node = node.next_sibling("student"))
	{
		cout << ">" << node.text().as_string()<< "<" << node.name();
		cout << "<" << node.name();
		pugixml_for_each_attribute(node);
		if (node.text())
		{
			cout << ">" << node.text().as_string()<< "<" << node.name();
		}
		cout <<"/>";
		cout << endl;
	}
#if 0
	/*���������ӽڵ�*/
	for(xml_node node = root.first_child(); node; node = node.next_sibling()){
		cout << "<" << node.name();
		pugixml_for_each_attribute(node);
		if (node.text())
		{
			cout << ">" << node.text().as_string()<< "<" << node.name();
		}
		cout <<"/>";
		cout << endl;
	}
#endif
#if 0
	/*method 2*/
	for (xml_node_iterator it = root.begin(); it != root.end(); ++it)
	{
		cout << "<" << node.name();
		pugixml_for_each_attribute(node);
		if (it->text())
		{
			cout << ">" << it->text().as_string()<< "<" << node.name();
		}
		cout <<"/>";
		cout << endl;
	}
#endif
	/*method 3*/
#if 0
	for each(xml_node &node in root.children())
	{
		cout << "<" << node.name();
		pugixml_for_each_attribute(node);
		if (it->text())
		{
			cout << ">" << it->text().as_string()<< "<" << node.name();
		}
		cout <<"/>";
		cout << endl;
	}
#endif
	return 0;
}	

int pugixml_for_each_attribute(xml_node &node)
{
#if 1
	/*method 1*/
	for each(xml_attribute &xattri in node.attributes())
	{
		cout << " " << xattri.name() << " = " << xattri.value();
	}
#endif

	/*method 2*/	
#if 0
	for (xml_attribute xattri = node.first_attribute(); xattri; xattri = xattri.next_attribute())
	{
		cout << xattri.name() << xattri.value();
	}
#endif
	/*method 3*/
#if 0
	for (xml_node::attribute_iterator iter = node.attributes_begin(); iter != node.attributes_end(); ++iter)
	{
		cout << " " << iter->name() << " = " << iter->value();
	}
#endif
	return 0;
}

