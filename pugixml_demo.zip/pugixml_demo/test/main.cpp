#include <pugixml.hpp>
#include "test_pugixml.h"
int main()
{
	int ret = test_pugixml_main();
	printf("\ntest_pugixml_main() error:%d\n", ret);
	system("pause");
	return ret;
}