#pragma once
#include "pugixml.hpp"
#include "pugiconfig.hpp"
#include <iostream>
using namespace std;
using namespace pugi;
struct PugiAttribute
{
	PugiAttribute()
	{

	}
	PugiAttribute(int _id, unsigned int _value, string _name)
	{
		id = _id;
		value = _value;
		name = _name;
	}
	int id;
	unsigned int value;
	string name;
};
/*entry pugixml main*/
int test_pugixml_main();

/*
xml_node xml_node::root() const;
xml_node xml_node::parent() const;  ���ڵ�
xml_node xml_node::first_child() const; ��һ���ӽڵ�
xml_node xml_node::last_child() const; ���һ���ӽڵ�
xml_node xml_node::next_sibling() const; ��һ���ֵܽڵ�
xml_node xml_node::previous_sibling() const; ǰһ���ֵܽڵ�

xml_attribute xml_node::first_attribute() const; ��һ������
xml_attribute xml_node::last_attribute() const; ���һ������
xml_attribute xml_attribute::next_attribute() const; ��һ������
xml_attribute xml_attribute::previous_attribute() const; ǰһ������

xml_attribute xml_node::append_attribute(const char_t* name);
xml_attribute xml_node::prepend_attribute(const char_t* name);  
xml_attribute xml_node::insert_attribute_after(const char_t* name, const xml_attribute& attr);
xml_attribute xml_node::insert_attribute_before(const char_t* name, const xml_attribute& attr);

xml_node xml_node::append_child(xml_node_type type = node_element);
xml_node xml_node::prepend_child(xml_node_type type = node_element);
xml_node xml_node::insert_child_after(xml_node_type type, const xml_node& node);
xml_node xml_node::insert_child_before(xml_node_type type, const xml_node& node);

xml_node xml_node::append_child(const char_t* name);
xml_node xml_node::prepend_child(const char_t* name);
xml_node xml_node::insert_child_after(const char_t* name, const xml_node& node);
xml_node xml_node::insert_child_before(const char_t* name, const xml_node& node);
*/
