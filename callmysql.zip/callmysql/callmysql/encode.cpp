#include "encode.h"
#include <windows.h>

/* multibyte to multibyte
 */
string MultiByteToMultiByte(unsigned nCodePage_To,unsigned nCodePage_From,const string& sInput)
{
	int nLen;
	string sOutput = "";
	
	/*don't need to convert case*/
	if (nCodePage_From == nCodePage_To)
	{
		return sInput;
	}

	/*calc length for convert from codepage to unicode */
	if ((nLen = MultiByteToWideChar (nCodePage_From, 0, sInput.c_str (), -1 , NULL, 0)) > 0)
	{
		WCHAR *pWBuffer = (WCHAR *)malloc (nLen * sizeof (WCHAR));
		if (pWBuffer)
		{
			/*convert from codepage to unicode */
			MultiByteToWideChar (nCodePage_From, 0, sInput.c_str (), -1, pWBuffer, nLen);

			/*calc len for convert unicode to utf8*/
			if ((nLen = WideCharToMultiByte (nCodePage_To, 0, pWBuffer, -1 , NULL, 0, NULL, NULL)) > 0)
			{
				char *pMBuffer = (char *)malloc (nLen);
				if (pMBuffer)
				{
					/*convert unicode to utf8*/
					WideCharToMultiByte (nCodePage_To, 0, pWBuffer, -1, pMBuffer, nLen, NULL, NULL);
					
					/*assign*/
					sOutput = pMBuffer;

					/*free pMBuffer*/
					free (pMBuffer);
				}
			}

			/*free pWBuffer*/
			free (pWBuffer);
		}
	}

	return sOutput;
}

/* utf8 to gbk
 */
string Utf8ToGbk(const string& sInput)
{
	return MultiByteToMultiByte (CP_ACP, CP_UTF8, sInput);
}

/* gbk to utf8
 */
string GbkToUtf8(const string& sInput)
{
	return MultiByteToMultiByte (CP_UTF8, CP_ACP, sInput);
}
