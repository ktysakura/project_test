#include "DbTable.h"

/* construct
**/
CDbTable::CDbTable(){

}

/* destruct
**/
CDbTable::~CDbTable(){

}

/* init
**/
int CDbTable::init(const vector<string>& vecCol){

	int i, nSize;
	map<string, int> mapCol;

	/* check size */
	if ((nSize = int(vecCol.size())) <= 0){
		return -1;
	}

	/* make map */
	for (i = 0; i < nSize; i++){
		if (int(vecCol[i].size()) <= 0){
			return -1;
		}
		if (!mapCol.insert(make_pair(vecCol[i], i)).second){
			return -2;
		}
	}

	/* init data */
	m_vecCol.assign(vecCol.begin(), vecCol.end());
	m_mapCol.insert(mapCol.begin(), mapCol.end());
	m_vecRow.clear();

	return 0;
}

/* add row
**/
int CDbTable::addRow(const vector<string>& row){

	int nColSize;
	
	/* check row size */
	if (((nColSize = this->countCol()) <= 0) || (nColSize != int(row.size()))){
		return -1;
	}

	/* push back row */
	m_vecRow.push_back(row);
	
	return 0;
}

/* count row
**/
int CDbTable::countRow() const{
	return int(m_vecRow.size());
}

/* count col
**/
int CDbTable::countCol() const{
	return int(m_vecCol.size());
}

/* get col name
**/
int CDbTable::getColName(int nColIndex, string& sColName) const{

	/* check col index */
	if ((nColIndex < 0) || (nColIndex >= this->countCol())){
		return -1;
	}
	
	/* assign col name */
	sColName = m_vecCol[nColIndex];

	return 0;
}

/* get col index
**/
int CDbTable::getColIndex(const string&sColName, int& nColIndex) const{

	map<string, int>::const_iterator mit;

	/* find col name */
	if (m_mapCol.end() == (mit = m_mapCol.find(sColName))){
		return -1;
	}

	/* assign col index */
	nColIndex = mit->second;

	return 0;
}

/* get value
**/
int CDbTable::getValue(int nRowIndex, int nColIndex, string& sValue) const{

	/* check row index */
	if ((nRowIndex < 0) || (nRowIndex >= this->countRow())){
		return -1;
	}

	/* check col index */
	if ((nColIndex < 0) || (nColIndex >= this->countCol())){
		return -2;
	}

	/* assign value */
	sValue = m_vecRow[nRowIndex][nColIndex];

	return 0;
}

/* get value
**/
int CDbTable::getValue(int nRowIndex, int nColIndex, int& nValue) const{

	int nRetCode;
	string sValue;

	/* get value */
	if (0 == (nRetCode = this->getValue(nRowIndex, nColIndex, sValue))){
		nValue = atoi(sValue.c_str());
	}

	return nRetCode;
}

/* get value
**/
int CDbTable::getValue(int nRowIndex, const string& sColName, string& sValue) const{
	
	int nColIndex;

	/* get col index */
	if (this->getColIndex(sColName, nColIndex) < 0){
		return -127;
	}

	return this->getValue(nRowIndex, nColIndex, sValue);
}

/* get value
**/
int CDbTable::getValue(int nRowIndex, const string& sColName, int& nValue) const{

	int nColIndex;

	/* get col index */
	if (this->getColIndex(sColName, nColIndex) < 0){
		return -127;
	}

	return this->getValue(nRowIndex, nColIndex, nValue);
}
