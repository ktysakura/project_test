#if !defined (ENCODE_H__20170930)
#define ENCODE_H__20170930

#include <string>
using namespace std;

/* function declare
 */
string MultiByteToMultiByte(unsigned int nCodePage_To,unsigned int nCodePage_From,const string& sInput);
string Utf8ToGbk(const string& sInput);
string GbkToUtf8(const string& sInput);

#endif //ENCODE_H__20170930
