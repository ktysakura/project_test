#if !defined (MYSQL_DB_H__20191108)
#define MYSQL_DB_H__20191108

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <mysql/mysql.h>
#include <mysql/errmsg.h>
#include "DbTable.h"
using namespace std;
#pragma comment(lib, "libmysql.lib")

class CMysqlDb
{
public:
	CMysqlDb();
	virtual ~CMysqlDb();

	int open(const string& sIp, int nPort, const string& sDbName, const string& sUserName, const string& sPassword);
	int escape(const string& sInput,string& sOutput);
	int exec(const string& sSql, vector<CDbTable>& vecTable);
	int close();
	bool isOpened();

private:
	int reopen();
	int escape(const char *szInput, int nInputSize, char *szOutput, int nOutputSize);

private:
	MYSQL *m_pmysql;
	int m_nPort;
	string m_sIp, m_sDbName, m_sUserName, m_sPassword;
};

#endif //MYSQL_DB_H__20191108
