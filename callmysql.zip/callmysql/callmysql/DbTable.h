#if !defined(DB_TABLE_H__20191107)
#define DB_TABLE_H__20191107

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <map>
using namespace std;

class CDbTable{
public:
	CDbTable();
	virtual ~CDbTable();

	int init(const vector<string>& vecCol);
	int addRow(const vector<string>& row);
	int countRow() const;
	int countCol() const;	
	int getColName(int nColIndex, string& sColName) const;
	int getColIndex(const string&sColName, int& nColIndex) const;
	int getValue(int nRowIndex, int nColIndex, string& sValue) const;
	int getValue(int nRowIndex, int nColIndex, int& nValue) const;
	int getValue(int nRowIndex, const string& sColName, string& sValue) const;	
	int getValue(int nRowIndex, const string& sColName, int& nValue) const;

private:
	vector<string> m_vecCol;
	map<string, int> m_mapCol;
	vector<vector<string>> m_vecRow;
};

#endif //DB_TABLE_H__20191107
