// callmysql.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include "MysqlDb.h"
#include "encode.h"

int _tmain(int argc, _TCHAR* argv[])
{
	CMysqlDb db;
	vector<CDbTable> vecTable;
	int i, j, k, nTableSize, nColSize, nRowSize;
	string sColName,sValue;

	/* open db */
	if (db.open("192.168.39.70", 3306, "db_translate", "root", "123456") < 0){
		printf("open db error\n");
		getchar();
		return -1;
	}
	printf("open db ok\n");

	/* exec query */
	if (db.exec("CALL sp_get_right_info(@errcode, @errmsg);SELECT @errcode,@errmsg;", vecTable) < 0){
		printf("exec sql error\n");
		getchar();
		return -2;
	}
	printf("exec sql ok\n");

	/* print table */
	nTableSize = int(vecTable.size());
	for (i = 0; i < nTableSize; i++){
		const CDbTable& table = vecTable[i];
		
		nRowSize = table.countRow();
		nColSize = table.countCol();

		for (j = 0; j < nColSize; j++){
			table.getColName(j, sColName);
			printf("col[%d] = %s\n", j, sColName.c_str());
		}
		for (j = 0; j < nRowSize; j++){
			for (k = 0; k < nColSize; k++){
				table.getValue(j, k, sValue);
				printf("value[%d][%d] = %s\n", j, k, Utf8ToGbk(sValue).c_str());
			}
		}
	}	
	
	/* close db */
	db.close();

	getchar();

	return 0;
}

