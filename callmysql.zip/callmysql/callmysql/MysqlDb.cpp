#include "MysqlDb.h"


/* construct
**/
CMysqlDb::CMysqlDb():m_pmysql (NULL){

}

/* destruct
**/
CMysqlDb::~CMysqlDb(){

	this->close();
}

/* open
**/
int CMysqlDb::open(const string& sIp, int nPort, const string& sDbName, const string& sUserName, const string& sPassword){

	MYSQL *pmysql = NULL;
	
	/* close old */
	this->close();

	/* init mysql */
	if (NULL == (pmysql = mysql_init (NULL))){		
		return -1;	
	}
	
	/* real coonnect */
	if (NULL == mysql_real_connect(pmysql, 
		sIp.c_str(), sUserName.c_str(), sPassword.c_str(), sDbName.c_str(), nPort, NULL, CLIENT_MULTI_STATEMENTS)){
		mysql_close (pmysql);	
		return -2;	
	}
	
	/* set character set */
	mysql_set_character_set (pmysql, "utf8");

	/* assign variable */
	m_pmysql = pmysql;
	m_sIp = sIp;
	m_nPort = nPort;
	m_sDbName = sDbName;;
	m_sUserName = sUserName;
	m_sPassword = sPassword;

	return 0;
}

/* reopen
**/
int CMysqlDb::reopen(){

	/* check whether have opened */
	if (NULL == m_pmysql){
		return -1;
	}

	/* close old */
	this->close();

	return this->open(m_sIp, m_nPort, m_sDbName, m_sUserName, m_sPassword);
}

/* query
**/
int CMysqlDb::exec(const string& sSql, vector<CDbTable>& vecTable){
		
	int nLength,nErrorNo;
	bool bTryReopen = false;

	/* check params */
	if ((NULL == m_pmysql) || ((nLength = (int)sSql.length()) <= 0)){
		return -1;
	}

	/* real query */
__MYSQL_REAL_QUERY:
	if (0 != mysql_real_query(m_pmysql, sSql.c_str(), nLength)){
		nErrorNo = mysql_errno(m_pmysql);
		if (((CR_SERVER_GONE_ERROR == nErrorNo) || (CR_SERVER_LOST == nErrorNo)) && (!bTryReopen)){
			bTryReopen = true;
			if (this->reopen() < 0){
				fprintf(stderr, "CMysqlDb try reopen error\n");
				return -2;
			}
			printf(" ### mysql db reopen ok\n");
			goto __MYSQL_REAL_QUERY;
		}
		else{
			fprintf(stderr, "mysql_real_query %s error (%s)\n", sSql.c_str(), mysql_error(m_pmysql));
			return -3;
		}
	}

	/* clear tables */
	vecTable.clear();

	/* store result */	
	do{ 		
		int i,nColSize;
		MYSQL_RES *pmysql_res = NULL;
		MYSQL_FIELD *pmysql_field = NULL;
		MYSQL_ROW mysql_row = NULL;
		vector<string> vecCol, vecRow;
		CDbTable table;
		
		/* check result */
		if (NULL == (pmysql_res = mysql_store_result (m_pmysql))){
			if (mysql_field_count (m_pmysql) > 0){
				return -4;
			}
			continue;
		}
		
		/* fetch cols */		
		while (NULL != (pmysql_field = mysql_fetch_field (pmysql_res))){
			vecCol.push_back(pmysql_field->name ? pmysql_field->name : "");
		}
		table.init(vecCol);
		
		/* fetch rows */
		nColSize = (int)vecCol.size();
		while (NULL != (mysql_row = mysql_fetch_row (pmysql_res))){			
			vecRow.clear();
			for (i = 0; i<nColSize; i++){
				vecRow.push_back(mysql_row[i] ? mysql_row[i] : "");
			}
			table.addRow(vecRow);
		}

		/* save table */
		vecTable.push_back(table);

		/* free resutl */
		mysql_free_result (pmysql_res);

	} while (0 == mysql_next_result (m_pmysql));

	return int(vecTable.size());
}

/* escape
**/
int CMysqlDb::escape(const char *szInput, int nInputSize, char *szOutput, int nOutputSize){

	/* check params */
	if ((NULL == m_pmysql) || (NULL == szOutput) || (nOutputSize < 2 * nInputSize + 1) || (NULL == szInput) || (nInputSize < 0)){
		return -1;
	}

	/* if input empty */
	if (0 == nInputSize){
		return 0;
	}

	/* escape string */
	if ((nOutputSize = (int)mysql_real_escape_string (m_pmysql, szOutput, szInput, nInputSize)) <= 0){
		return -2;
	}

	return nOutputSize;
}

/* escape
**/
int CMysqlDb::escape(const string& sInput, string& sOutput){

	char *pOutput = NULL;
	int nInputSize, nOutputSize;

	/* check input size */
	if ((nInputSize = int(sInput.size())) <= 0){
		return -1;
	}

	/* malloc output */
	nOutputSize = 2 * nInputSize + 1;
	if (NULL == (pOutput = (char *)malloc(nOutputSize))){
		return -2;
	}

	/* escape string */
	if ((nOutputSize = this->escape(sInput.c_str(), nInputSize, pOutput, nOutputSize)) > 0){
		sOutput.assign(pOutput, nOutputSize);
	}
	else{
		nOutputSize = -3;
	}

	/* free output */
	free(pOutput);

	return nOutputSize;
}

/* close
**/
int CMysqlDb::close(){

	/* close mysql */
	if (NULL != m_pmysql){
		mysql_close (m_pmysql);
		m_pmysql = NULL;
	}
	
	return 0;
}

/* is opened
**/
bool CMysqlDb::isOpened(){
	return (NULL != m_pmysql);
}
